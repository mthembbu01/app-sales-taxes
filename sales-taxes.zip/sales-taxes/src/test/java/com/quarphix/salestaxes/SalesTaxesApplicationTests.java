package com.quarphix.salestaxes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesTaxesApplicationTests {

	@Test
	void contextLoads() {
	}

}
